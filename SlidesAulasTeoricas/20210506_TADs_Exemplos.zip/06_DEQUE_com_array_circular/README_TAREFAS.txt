
1 - Especificar a interface do tipo DEQUE - ficheiro .h

2 - Estabelecer a representação interna, usando um ARRAY CIRCULAR - ficheiro .c

3 - Implementar as várias funções

4 - Testar com novos exemplos de aplicação

Sugestão: considere as semelhanças com o TAD QUEUE implementado com um array circular