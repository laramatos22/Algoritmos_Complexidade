
1 - Completar as funções em falta no ficheiro .c

2 - Fazer os exemplos de aplicação anteriores !!