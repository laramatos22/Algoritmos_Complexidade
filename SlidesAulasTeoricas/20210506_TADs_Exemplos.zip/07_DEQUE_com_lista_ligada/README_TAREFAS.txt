
*** Usar o TAD LISTA como base do TAD DEQUE ***

1 - Especificar a interface do tipo DEQUE, ser qualquer referência ao TAD LISTA - ficheiro .h

2 - Estabelecer a representação interna, usando o TAD LISTA - ficheiro .c

3 - Implementar as várias funções, usando as correspondentes funções do TAD LISTA

4 - Testar com novos exemplos de aplicação

