
Hash Table using Open Addressing

Partially based on source code from

*The Joys of Hashing*

by Thomas Mailund 

https://www.apress.com/9781484240656